# =============================================================
# evidence/evidence_writer.py
# Persist accepted clusters to the evidence table and rejected
# clusters to low_confidence_staging.
# All DB access via api/db.py connection pool.
# =============================================================

import json
import logging
import os
from collections import Counter
from typing import Any

from api.db import get_conn, release_conn

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def compute_source_lineage(items: list[dict[str, Any]]) -> dict[str, float]:
    """Compute the percentage breakdown of cluster items by source.

    Args:
        items: List of cluster item dicts, each expected to have a 'source' key.

    Returns:
        Dict mapping source name to its share of the total as a float
        rounded to 4 decimal places. Percentages sum to 1.0.
        Returns {} if items is empty.
    """
    if not items:
        return {}

    counts = Counter(item.get("source", "unknown") for item in items)
    total = len(items)
    lineage = {
        source: round(count / total, 4)
        for source, count in counts.items()
    }

    # Correct floating-point rounding drift so values always sum to exactly 1.0.
    # Adjust the largest bucket by the accumulated error.
    current_sum = sum(lineage.values())
    if current_sum != 1.0:
        largest = max(lineage, key=lineage.__getitem__)
        lineage[largest] = round(lineage[largest] + (1.0 - current_sum), 4)

    return lineage


def _most_common_source(items: list[dict[str, Any]]) -> str:
    """Return the source that appears most frequently among items.

    Args:
        items: Cluster item dicts with a 'source' key.

    Returns:
        Source string, or 'unknown' if items is empty.
    """
    if not items:
        return "unknown"
    counts = Counter(item.get("source", "unknown") for item in items)
    return counts.most_common(1)[0][0]


def _extract_quotes(items: list[dict[str, Any]], limit: int = 5) -> list[str]:
    """Extract up to `limit` non-empty text strings from cluster items.

    Args:
        items: Cluster item dicts with a 'text' key.
        limit: Maximum number of quotes to return.

    Returns:
        List of non-empty text strings, up to `limit` in length.
    """
    quotes = []
    for item in items:
        text = (item.get("text") or "").strip()
        if text:
            quotes.append(text)
        if len(quotes) >= limit:
            break
    return quotes


def _build_theme(quotes: list[str], max_len: int = 500) -> str:
    """Build a theme string from the first 3 representative quotes.

    Joins with ' | ' and truncates to `max_len` characters.

    Args:
        quotes: List of text strings.
        max_len: Maximum character length of the returned theme string.

    Returns:
        Theme string, possibly truncated with a trailing '…'.
    """
    joined = " | ".join(quotes[:3])
    if len(joined) <= max_len:
        return joined
    return joined[: max_len - 1] + "\u2026"


def _vector_to_pg(vector: list[float]) -> str:
    """Format a list of floats as a pgvector literal string.

    Args:
        vector: Embedding vector.

    Returns:
        String like '[0.1,0.2,...]' suitable for %s::vector cast.
    """
    return "[" + ",".join(str(v) for v in vector) + "]"


def _list_to_pg_array(strings: list[str]) -> str:
    """Format a list of strings as a PostgreSQL text array literal.

    Escapes internal double-quotes and backslashes so the literal is
    safe to pass via %s.

    Args:
        strings: List of strings.

    Returns:
        String like '{"foo","bar with \\"quote\\""}' accepted by psycopg2
        when cast to text[].
    """
    def escape(s: str) -> str:
        return s.replace("\\", "\\\\").replace('"', '\\"')

    escaped = ", ".join(f'"{escape(s)}"' for s in strings)
    return "{" + escaped + "}"


# ---------------------------------------------------------------------------
# Public writers
# ---------------------------------------------------------------------------

def write_evidence(cluster: dict[str, Any], confidence_score: float) -> str:
    """Insert an accepted cluster into the evidence table.

    Computes source lineage, extracts representative quotes, derives a
    theme, and inserts a full evidence row. Uses RETURNING id to capture
    the UUID assigned by the database.

    Args:
        cluster:          Cluster dict with 'items' and 'centroid_vector' keys.
        confidence_score: Float in [0.0, 1.0] from compute_confidence().

    Returns:
        String UUID of the newly inserted evidence row.

    Raises:
        Exception: Re-raises any DB exception after rollback so the caller
                   can count and log the error.
    """
    items = cluster.get("items", [])
    centroid = cluster.get("centroid_vector", [])
    model_version = os.environ["BEDROCK_EMBED_MODEL"]

    source_lineage = compute_source_lineage(items)
    quotes = _extract_quotes(items, limit=5)
    theme = _build_theme(quotes)
    unique_user_count = len(items)
    vector_str = _vector_to_pg(centroid)
    quotes_array = _list_to_pg_array(quotes)

    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO evidence (
                    theme,
                    representative_quotes,
                    unique_user_count,
                    confidence_score,
                    source_lineage,
                    embedding_vector,
                    embedding_model_version,
                    status,
                    created_at,
                    last_validated_at
                ) VALUES (
                    %s,
                    %s::text[],
                    %s,
                    %s,
                    %s::jsonb,
                    %s::vector,
                    %s,
                    'active',
                    NOW(),
                    NOW()
                )
                RETURNING id
                """,
                (
                    theme,
                    quotes_array,
                    unique_user_count,
                    confidence_score,
                    json.dumps(source_lineage),
                    vector_str,
                    model_version,
                ),
            )
            evidence_id = str(cur.fetchone()[0])
        conn.commit()

        logger.info(
            "write_evidence: id=%s cluster=%s score=%.4f size=%d sources=%s",
            evidence_id, cluster.get("cluster_id"), confidence_score,
            unique_user_count, list(source_lineage.keys()),
        )
        return evidence_id

    except Exception as exc:
        conn.rollback()
        logger.error(
            "write_evidence failed: cluster=%s error=%s",
            cluster.get("cluster_id"), exc,
        )
        raise
    finally:
        release_conn(conn)


def write_staging(cluster: dict[str, Any], confidence_score: float) -> str:
    """Insert or update a rejected cluster in low_confidence_staging.

    Uses ON CONFLICT on content_hash to increment the frequency counter
    when the same low-confidence content recurs across ingestion runs.
    The Governance Agent monitors frequency to detect emerging patterns.

    Args:
        cluster:          Cluster dict with 'items' key.
        confidence_score: Float in [0.0, 1.0].

    Returns:
        String UUID of the inserted or updated staging row.

    Raises:
        Exception: Re-raises any DB exception after rollback.
    """
    items = cluster.get("items", [])

    # content_hash from the first item (the cluster seed).
    first_item = items[0] if items else {}
    content_hash = first_item.get("hash", cluster.get("cluster_id", ""))
    source = _most_common_source(items)

    raw_text = (first_item.get("text") or "").strip()
    if len(raw_text) > 500:
        raw_text = raw_text[:499] + "\u2026"

    cluster_size = len(items)

    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO low_confidence_staging (
                    content_hash,
                    source,
                    raw_text_sample,
                    confidence_score,
                    cluster_size,
                    frequency,
                    first_seen,
                    last_seen,
                    promoted
                ) VALUES (
                    %s, %s, %s, %s, %s,
                    1,
                    NOW(), NOW(),
                    FALSE
                )
                ON CONFLICT (content_hash) DO UPDATE
                    SET frequency    = low_confidence_staging.frequency + 1,
                        last_seen    = NOW(),
                        cluster_size = EXCLUDED.cluster_size
                RETURNING id
                """,
                (
                    content_hash,
                    source,
                    raw_text or None,
                    confidence_score,
                    cluster_size,
                ),
            )
            staging_id = str(cur.fetchone()[0])
        conn.commit()

        logger.info(
            "write_staging: id=%s cluster=%s hash=%s score=%.4f size=%d",
            staging_id, cluster.get("cluster_id"), content_hash,
            confidence_score, cluster_size,
        )
        return staging_id

    except Exception as exc:
        conn.rollback()
        logger.error(
            "write_staging failed: cluster=%s error=%s",
            cluster.get("cluster_id"), exc,
        )
        raise
    finally:
        release_conn(conn)
